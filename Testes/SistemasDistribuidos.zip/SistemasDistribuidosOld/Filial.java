import java.rmi.Naming;
import java.util.ArrayList;

public class Filial{
  private ArrayList listaClientes = new ArrayList();

  public void novoCliente(String nome){
        Cliente cliente = new Cliente(nome);
        listaClientes.add(cliente);
  }

  public void alugaCarro(int numero){
        for(int i = 0; i < listaClientes.size(); i++){
          Cliente c = (Cliente) listaClientes.get(i);
          if(c.getNumero() == numero){
            c.setDebito(true);
            System.out.println("Alugado");
          }
        }
  }

  public int locação(int numero, String nome){
    int filial = rmi("consultaFilial", nome, numero, 0);
    return filial;
  }

  public void devolucao(Cliente cliente){
    cliente.setDebito(false);
  }

  public int rmi (String nomeFuncao, String nome, int numero, int filial){
    int i = 0;
    try{
      Matrix c = (Matrix) Naming.lookup("rmi://192.168.43.209/MatrixService");
      if(nomeFuncao.equals("addCliente")){
          System.out.println("Retorno: " +c.addCliente(numero, nome, filial));
          i = -1;
      }else if(nomeFuncao.equals("add")){
          System.out.println("Adicao : "+c.add(10,15));
          i = -1;
      }else if (nomeFuncao.equals("consultaFilial")){
          i = c.consultaFilial(numero, nome);
      }
    }catch (Exception e){
      e.printStackTrace();
    }
    return i;
  }

  public void imprimeLista(){
    for(int i = 0; i < listaClientes.size(); i++){
      Cliente c = (Cliente) listaClientes.get(i);
      System.out.println("Nome: " + c.getNome() + " numero: " + c.getNumero());
    }
  }
}
