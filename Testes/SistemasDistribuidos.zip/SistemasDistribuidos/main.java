import java.util.ArrayList;

public class main{
  private static ArrayList<Filial> filial = new ArrayList<Filial>();

  public static void main(String[] args){

    Filial filial1 = new Filial();
    filial1.novoCliente("Bruno");
    filial1.rmi("addCliente", "Bruno", 1, 1);
    Filial filial2 = new Filial();
    filial2.novoCliente("Claudio");
    filial1.rmi("addCliente", "Claudio",1 , 2);
    Filial filial3 = new Filial();
    filial3.novoCliente("Lucas");
    filial1.rmi("addCliente", "Lucas", 1, 3);

    filial1.imprimeLista();

    filial.add(filial1);
    filial.add(filial2);
    filial.add(filial3);

    alugar(1,1,"Bruno");
    alugar(2,1,"Claudio");
    alugar(3,1,"Lucas");
  }

  public static void alugar(int f, int numero, String nome){
    int i = filial.get(f-1).locação(numero, nome);
    System.out.println("Filial: " + i);
    filial.get(i-1).alugaCarro(numero);
  }
}
